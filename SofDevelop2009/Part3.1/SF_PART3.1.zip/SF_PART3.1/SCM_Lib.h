#include "UT_DM_Defines.h"

int SCM_create(int argc, char* argv[]);
int SCM_buildIndex(int argc, char* argv[]);
int SCM_destroy(int argc, char* argv[]);
int SCM_print(char * relName);

int Scan_relcat(char *);
int Scan_attrcat(char *);
