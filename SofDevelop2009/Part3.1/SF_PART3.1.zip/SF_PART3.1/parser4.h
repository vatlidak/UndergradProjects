#ifndef PARSER3
#define PARSER3

#define RESTART -3

int yyparse(void);

#endif
